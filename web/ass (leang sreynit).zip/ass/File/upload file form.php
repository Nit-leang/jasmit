
<!DOCTYPE html>
<html>
<head>
    <meta chareset="utf-8"/>
    <meta http-equiv="X-UA-Compatible" content="IE=edge"/>
    <title> Page Tile</title>
    <meta name="viewport" content="width=device-width, initial-scale=1"/>
</head>
<body>
    <form action="upload_file.php" method="post" enctype="multipart/form-data">
        <lable for="file">FileName/><lable>
        <input type="file" name="file" id="file"></br>
        <input type="submit" name="file" value="Submit"/><br/>
    </form>
</body>
</html>
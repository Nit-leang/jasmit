<?php
$file="data.text";
readfile($file);
?>
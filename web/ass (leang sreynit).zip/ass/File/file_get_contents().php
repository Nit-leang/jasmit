<?php
$file="data.text";
$content=  file_get_contents($file);
echo $content;
?>
<?php
require_once('demo.php');
$objDemo = new Demo();
$objDemo->name= "sok sabay";
$objDemo->sayHello();
?>
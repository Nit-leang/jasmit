<?php
class demo{
    public $name;
    function sayHello(){
        echo "Hello $name->name !";
    }
}
?>
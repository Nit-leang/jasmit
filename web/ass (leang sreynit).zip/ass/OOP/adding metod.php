<?php
class demo{
    function sayHello($name){
        echo "Hello $name!";
    }
}
?>


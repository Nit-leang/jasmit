<!DOCTYPE>
<html>
<head>
<style>
.form{
    border: 1px solid black;
    width: 100px;
    height:100px;
    margin-left:330px;
}
</style>
</head>
<body>
<form action="add.php" class="form">
<?php
echo "Record Succes!";
?>
</form>
</body>
</html>